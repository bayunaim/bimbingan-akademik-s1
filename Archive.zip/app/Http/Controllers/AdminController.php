<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\DosenImport;
use App\Imports\MahasiswaImport;
use App\Exports\DosenTemplateExport;
use App\Exports\MahasiswaTemplateExport;

class AdminController extends Controller
{
    // ==========================================
    // KELOLA DATA DOSEN
    // ==========================================
    public function indexDosen()
    {
        $dosens = User::where('role', 'dosen')->latest()->get();
        return view('admin.dosen.index', compact('dosens'));
    }

    public function storeDosen(Request $request)
    {
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'nomor_induk' => $request->nomor_induk, // NIP
            'password' => Hash::make('password123'), // Password default
            'role' => 'dosen',
        ]);
        return back()->with('success', 'Data Dosen berhasil ditambahkan!');
    }

    // ==========================================
    // KELOLA DATA MAHASISWA & PLOTTING DOSEN
    // ==========================================
    public function indexMahasiswa()
    {
        // Ambil mahasiswa beserta data dosen pembimbingnya (relasi)
        $mahasiswas = User::where('role', 'mahasiswa')->with('dosenPembimbing')->latest()->get();
        // Ambil data dosen untuk dropdown plotting
        $dosens = User::where('role', 'dosen')->get();

        return view('admin.mahasiswa.index', compact('mahasiswas', 'dosens'));
    }

    public function storeMahasiswa(Request $request)
    {
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'nomor_induk' => $request->nomor_induk, // NIM
            'dosen_id' => $request->dosen_id, // Ini proses plotting-nya
            'password' => Hash::make('password123'), // Password default
            'role' => 'mahasiswa',
        ]);
        return back()->with('success', 'Data Mahasiswa dan Plotting berhasil disimpan!');
    }

    // --- FITUR EXCEL DOSEN ---
    public function templateDosen()
    {
        // Jauh lebih bersih dan elegan kan bro?
        return Excel::download(new DosenTemplateExport, 'Template_Dosen.xlsx');
    }

    public function importDosen(Request $request)
    {
        $request->validate(['file_excel' => 'required|mimes:xlsx,xls,csv']);
        Excel::import(new DosenImport, $request->file('file_excel'));
        return back()->with('success', 'Data Dosen berhasil di-import massal!');
    }

    // --- FITUR EXCEL MAHASISWA ---
    public function templateMahasiswa()
    {
        return Excel::download(new MahasiswaTemplateExport, 'Template_Mahasiswa_Plotting.xlsx');
    }

    public function importMahasiswa(Request $request)
    {
        $request->validate(['file_excel' => 'required|mimes:xlsx,xls,csv']);
        Excel::import(new MahasiswaImport, $request->file('file_excel'));
        return back()->with('success', 'Data Mahasiswa & Plotting berhasil di-import massal!');
    }

    // Menampilkan halaman form edit plotting
    public function editMahasiswa($id)
    {
        $mahasiswa = User::where('role', 'mahasiswa')->findOrFail($id);
        $dosens = User::where('role', 'dosen')->get();

        return view('admin.mahasiswa.edit', compact('mahasiswa', 'dosens'));
    }

    // Memproses perubahan Dosen Pembimbing
    // Memproses perubahan Data Mahasiswa & Plotting
    public function updateMahasiswa(Request $request, $id)
    {
        // 1. Validasi inputan biar aman
        $request->validate([
            'name' => 'required|string|max:255',
            'nomor_induk' => 'required|string|max:255',
            // Pastikan email unik, tapi abaikan email milik dia sendiri
            'email' => 'required|email|max:255|unique:users,email,'.$id,
        ]);

        $mahasiswa = User::findOrFail($id);

        // 2. Update semua datanya
        $mahasiswa->update([
            'name' => $request->name,
            'nomor_induk' => $request->nomor_induk,
            'email' => $request->email,
            'dosen_id' => $request->dosen_id
        ]);

        return redirect()->route('admin.mahasiswa')->with('success', 'Data Mahasiswa '.$mahasiswa->name.' berhasil diperbarui!');
    }

    // Menampilkan halaman form edit dosen
    public function editDosen($id)
    {
        $dosen = User::where('role', 'dosen')->findOrFail($id);
        return view('admin.dosen.edit', compact('dosen'));
    }

    // Memproses perubahan Data Dosen
    public function updateDosen(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'nomor_induk' => 'required|string|max:255', // NIP/NIDN
            'email' => 'required|email|max:255|unique:users,email,'.$id,
        ]);

        $dosen = User::findOrFail($id);

        $dosen->update([
            'name' => $request->name,
            'nomor_induk' => $request->nomor_induk,
            'email' => $request->email,
        ]);

        return redirect()->route('admin.dosen')->with('success', 'Data Dosen '.$dosen->name.' berhasil diperbarui!');
    }
}
