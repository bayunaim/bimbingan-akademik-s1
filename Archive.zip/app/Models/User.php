<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

#[Fillable(['name', 'email', 'password'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    protected $fillable = [
        'name',
        'email',
        'password',
        'role', // Tambahkan ini bro
        'nomor_induk', // Tambahan baru
        'dosen_id',    // Tambahan baru
    ];
    // Relasi untuk Mahasiswa: Mengambil data Dosen Pembimbingnya
    public function dosenPembimbing()
    {
        return $this->belongsTo(User::class, 'dosen_id');
    }

    // Relasi untuk Dosen: Mengambil semua Mahasiswa bimbingannya
    public function mahasiswaBimbingan()
    {
        return $this->hasMany(User::class, 'dosen_id');
    }
}
