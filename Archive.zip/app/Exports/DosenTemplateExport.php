<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class DosenTemplateExport implements FromArray, WithHeadings, ShouldAutoSize
{
    public function headings(): array
    {
        // Ini baris pertama (Header)
        return [
            'nama',
            'nip',
            'email'
        ];
    }

    public function array(): array
    {
        // Ini baris kedua (Contoh Isian)
        return [
            ['Dr. Budi Santoso, M.Or', '198001012005011001', 'budi@binaguna.ac.id']
        ];
    }
}
