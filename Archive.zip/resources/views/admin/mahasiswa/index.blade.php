<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Kelola Data Mahasiswa & Plotting') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if(session('success'))
                <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline">{{ session('success') }}</span>
                </div>
            @endif

            <div class="bg-white p-6 shadow-sm sm:rounded-xl border border-gray-100">
                <div class="bg-emerald-50 p-6 shadow-sm sm:rounded-xl border border-emerald-100 flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                        <h3 class="text-lg font-bold text-emerald-800">Import Data Massal (Dengan Plotting)</h3>
                        <p class="text-sm text-emerald-600">Isi NIP Dosen di kolom Excel untuk otomatis menghubungkan mahasiswa dengan dosennya.</p>
                    </div>
                    <form action="{{ route('admin.mahasiswa.import') }}" method="POST" enctype="multipart/form-data" class="flex items-center gap-3">
                        @csrf
                        <a href="{{ route('admin.mahasiswa.template') }}" class="text-sm font-semibold text-emerald-700 bg-white border border-emerald-300 px-4 py-2 rounded-lg hover:bg-emerald-100 transition">⬇️ Download Template</a>
                        <input type="file" name="file_excel" accept=".csv, .xlsx, .xls" required class="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-emerald-600 file:text-white hover:file:bg-emerald-700 cursor-pointer">
                        <button type="submit" class="bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-2 px-6 rounded-lg text-sm transition shadow-sm">Upload</button>
                    </form>
                </div>
                <h3 class="text-lg font-bold text-emerald-600 mb-4 border-b pb-2">Tambah Mahasiswa Baru</h3>
                <form action="{{ route('admin.mahasiswa.store') }}" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    @csrf
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nama Mahasiswa</label>
                        <input type="text" name="name" required class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm focus:border-emerald-500 focus:ring-emerald-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">NIM</label>
                        <input type="text" name="nomor_induk" required class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm focus:border-emerald-500 focus:ring-emerald-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email Akun (Untuk Login)</label>
                        <input type="email" name="email" required class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm focus:border-emerald-500 focus:ring-emerald-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Plotting Dosen Pembimbing</label>
                        <select name="dosen_id" required class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm focus:border-emerald-500 focus:ring-emerald-500">
                            <option value="">-- Pilih Dosen Pembimbing --</option>
                            @foreach($dosens as $dosen)
                                <option value="{{ $dosen->id }}">{{ $dosen->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="md:col-span-2 mt-2">
                        <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-lg text-sm transition">Simpan & Plotting</button>
                        <span class="text-xs text-gray-500 ml-3">*Password default: <b>password123</b></span>
                    </div>
                </form>
            </div>

            <div class="bg-white shadow-sm sm:rounded-xl border border-gray-100 overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Nama Mahasiswa</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">NIM</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Dosen Pembimbing</th>
                            <th class="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @foreach($mahasiswas as $mhs)
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{{ $mhs->name }}</td>
                            <td class="px-6 py-3 whitespace-nowrap text-sm text-gray-600">{{ $mhs->nomor_induk ?? '-' }}</td>
                            <td class="px-6 py-3 whitespace-nowrap text-sm font-bold text-indigo-600">
                                {{ $mhs->dosenPembimbing ? $mhs->dosenPembimbing->name : 'Belum Diplot' }}
                            </td>
                            <td class="px-6 py-3 whitespace-nowrap text-center">
                                <a href="{{ route('admin.mahasiswa.edit', $mhs->id) }}" class="inline-flex items-center px-3 py-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-md text-sm font-semibold transition">
                                    ✏️ Ubah Data
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</x-app-layout>
